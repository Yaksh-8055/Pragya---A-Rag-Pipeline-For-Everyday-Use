"""Built-in Stage 1 parsers."""
