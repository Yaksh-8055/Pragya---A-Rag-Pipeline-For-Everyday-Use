"""Layout-aware parsing for DOCX, PDF and HTML."""
from __future__ import annotations

from pathlib import Path


def _docx(path: Path) -> dict:
    from docx import Document

    doc = Document(str(path))
    components = []
    blocks = []

    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        if text:
            style = getattr(paragraph.style, "name", None)
            blocks.append(text)
            components.append({"type": "paragraph", "text": text, "style": style})

    for table_index, table in enumerate(doc.tables):
        rows = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            rows.append(cells)
            blocks.append(" | ".join(cells))
        components.append({"type": "table", "index": table_index, "rows": rows})

    return {
        "text": "\n\n".join(blocks),
        "components": components,
        "metadata": {
            "parser": "layout",
            "format": "docx",
            "paragraph_count": len(doc.paragraphs),
            "table_count": len(doc.tables),
        },
    }


def _pdf(path: Path) -> dict:
    import fitz

    document = fitz.open(str(path))
    components = []
    blocks = []
    try:
        for number, page in enumerate(document, start=1):
            text = page.get_text("text").strip()
            if text:
                blocks.append(text)
                components.append({"type": "page", "page": number, "text": text})
    finally:
        document.close()

    return {
        "text": "\n\n".join(blocks),
        "components": components,
        "metadata": {"parser": "layout", "format": "pdf", "page_count": len(components)},
    }


def _html(path: Path) -> dict:
    from bs4 import BeautifulSoup

    html = path.read_text(encoding="utf-8", errors="replace")
    soup = BeautifulSoup(html, "html.parser")
    for node in soup(["script", "style", "noscript", "template"]):
        node.decompose()

    title = soup.title.get_text(" ", strip=True) if soup.title else None
    text = soup.get_text("\n", strip=True)
    components = []
    for tag in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "pre", "code", "blockquote"]):
        value = tag.get_text(" ", strip=True)
        if value:
            components.append({"type": tag.name, "text": value})

    return {
        "text": text,
        "components": components,
        "metadata": {"parser": "layout", "format": "html", "title": title},
    }


def parse(file_path: str | Path) -> dict:
    path = Path(file_path)
    ext = path.suffix.lower()
    if ext == ".docx":
        return _docx(path)
    if ext == ".pdf":
        return _pdf(path)
    if ext in {".html", ".htm"}:
        return _html(path)
    raise ValueError(f"layout parser does not support {ext!r}")
