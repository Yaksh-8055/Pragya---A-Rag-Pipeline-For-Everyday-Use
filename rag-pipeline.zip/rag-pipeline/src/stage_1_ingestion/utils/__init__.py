"""Stage 1 utility helpers."""
