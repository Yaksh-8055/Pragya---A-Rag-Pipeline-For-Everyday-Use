"""Stage 1 ingestion package."""
from .router import ingestion_routing_validation

__all__ = ["ingestion_routing_validation"]
