# RAG Architecture Specification

## Offline Ingestion Phase
Stage 1 routes files based on MIME type and text layer checks. Stage 2 uses recursive structure-aware chunking bounded by tiktoken token counts. Stage 3 generates 768-dimensional dense vector embeddings using nomic-embed-text. Stage 4 stores vector coordinates in ChromaDB and raw context payloads in SQLite.

## Online Retrieval Phase
Stage 5 queries ChromaDB for Approximate Nearest Neighbors, calculates cosine similarity, and batch-hydrates matching chunk records from SQLite. Stage 6 applies single-pass token budgeting with safety margins and streams grounded responses using the Qwen 4B local LLM.