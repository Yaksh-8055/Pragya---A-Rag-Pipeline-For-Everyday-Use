# Introduction to RAG Systems
Retrieval-Augmented Generation (RAG) combines external knowledge bases with large language models.
This prevents hallucinations and provides accurate grounding for responses.

## Stage One: Ingestion and Routing
The pipeline must handle diverse file types gracefully. It separates plain text, structured data, and complex layouts like PDFs.
Unsupported files like audio and video are immediately dropped at the gatekeeper stage.

## Stage Two: Structure-Aware Chunking
Instead of cutting text blindly, recursive chunking respects headers, paragraphs, and sentence lines.
Using tiktoken ensures that token limits are strictly enforced, protecting local hardware VRAM limits.
